import { Heading } from './PageHeading.styled';

export const PageHeading = ({ children }) => {
  return <Heading>{children}</Heading>;
};
