import { PageHeading } from 'components/PageHeading/PageHeading';

export const HomeView = () => {
  return (
    <>
      <PageHeading>Добро пожаловать</PageHeading>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex vel velit
        nihil illo est! Quos cum rerum dolores voluptates odio iste est nam
        excepturi placeat eligendi voluptatibus a illo eos ipsam, necessitatibus
        quo at quae pariatur et asperiores odit! Quasi sunt odit omnis at
        deserunt placeat ipsa earum dignissimos magni voluptatum quisquam veniam
        libero qui fugit accusantium cum ratione, facilis tempore in!
        Voluptates, minus nesciunt sed optio voluptate et quae accusamus est
        eos, dolorum quibusdam dolorem debitis perferendis voluptas rem quos
        eius ab, commodi cumque dolor. Repellendus porro impedit, enim
        temporibus quibusdam eum natus corporis id? Ducimus fugit consequatur
        consequuntur.
      </p>

      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex vel velit
        nihil illo est! Quos cum rerum dolores voluptates odio iste est nam
        excepturi placeat eligendi voluptatibus a illo eos ipsam, necessitatibus
        quo at quae pariatur et asperiores odit! Quasi sunt odit omnis at
        deserunt placeat ipsa earum dignissimos magni voluptatum quisquam veniam
        libero qui fugit accusantium cum ratione, facilis tempore in!
        Voluptates, minus nesciunt sed optio voluptate et quae accusamus est
        eos, dolorum quibusdam dolorem debitis perferendis voluptas rem quos
        eius ab, commodi cumque dolor. Repellendus porro impedit, enim
        temporibus quibusdam eum natus corporis id? Ducimus fugit consequatur
        consequuntur.
      </p>

      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex vel velit
        nihil illo est! Quos cum rerum dolores voluptates odio iste est nam
        excepturi placeat eligendi voluptatibus a illo eos ipsam, necessitatibus
        quo at quae pariatur et asperiores odit! Quasi sunt odit omnis at
        deserunt placeat ipsa earum dignissimos magni voluptatum quisquam veniam
        libero qui fugit accusantium cum ratione, facilis tempore in!
        Voluptates, minus nesciunt sed optio voluptate et quae accusamus est
        eos, dolorum quibusdam dolorem debitis perferendis voluptas rem quos
        eius ab, commodi cumque dolor. Repellendus porro impedit, enim
        temporibus quibusdam eum natus corporis id? Ducimus fugit consequatur
        consequuntur.
      </p>

      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex vel velit
        nihil illo est! Quos cum rerum dolores voluptates odio iste est nam
        excepturi placeat eligendi voluptatibus a illo eos ipsam, necessitatibus
        quo at quae pariatur et asperiores odit! Quasi sunt odit omnis at
        deserunt placeat ipsa earum dignissimos magni voluptatum quisquam veniam
        libero qui fugit accusantium cum ratione, facilis tempore in!
        Voluptates, minus nesciunt sed optio voluptate et quae accusamus est
        eos, dolorum quibusdam dolorem debitis perferendis voluptas rem quos
        eius ab, commodi cumque dolor. Repellendus porro impedit, enim
        temporibus quibusdam eum natus corporis id? Ducimus fugit consequatur
        consequuntur.
      </p>
    </>
  );
};
